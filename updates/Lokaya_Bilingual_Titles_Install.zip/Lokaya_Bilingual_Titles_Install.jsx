#target aftereffects
(function(){
 var helper="/* lokaya-bilingual-import-v1 */\nfunction lkPrepareBilingual(items){\n if(typeof ComposerEngine==='undefined'||typeof ParagraphDirection==='undefined')throw Error('Arabic composition requires After Effects 24.0 or later.');\n var changed=0;\n for(var ci=0;ci<items.length;ci++){var c=items[ci];if(!(c instanceof CompItem))continue;\n for(var li=1;li<=c.numLayers;li++){var g=c.layer(li).property('ADBE Text Properties');if(!g)continue;var p=g.property('ADBE Text Document');if(!p)continue;\n for(var ki=1;ki<=Math.max(1,p.numKeys);ki++){\n var t=p.numKeys?p.keyValue(ki):p.valueAtTime(0,true);\n t.composerEngine=ComposerEngine.UNIVERSAL_TYPE_ENGINE;t.direction=ParagraphDirection.DIRECTION_RIGHT_TO_LEFT;t.font='Arial';\n if(p.numKeys)p.setValueAtKey(ki,t);else p.setValue(t);\n var v=p.numKeys?p.keyValue(ki):p.valueAtTime(0,true);\n if(v.composerEngine!==ComposerEngine.UNIVERSAL_TYPE_ENGINE||v.direction!==ParagraphDirection.DIRECTION_RIGHT_TO_LEFT)throw Error('After Effects did not retain Arabic composition in '+c.name+'/'+c.layer(li).name);\n changed++;\n }}}\n return changed;\n}\n";
 var roots=[Folder.userData.fsName+'/Adobe/CEP/extensions',Folder.appData.fsName+'/Adobe/CEP/extensions','/Library/Application Support/Adobe/CEP/extensions',Folder('~/Library/Application Support/Adobe/CEP/extensions').fsName,'C:/Program Files (x86)/Common Files/Adobe/CEP/extensions','C:/Program Files/Common Files/Adobe/CEP/extensions'];
 var done={},count=0,errors=[];
 for(var ri=0;ri<roots.length;ri++){var root=new Folder(roots[ri]);if(!root.exists)continue;var dirs=root.getFiles(function(f){return f instanceof Folder;});
 for(var di=0;di<dirs.length;di++){var f=new File(dirs[di].fsName+'/jsx/elements_import.jsx');if(!f.exists||done[f.fsName])continue;done[f.fsName]=true;
 try{f.encoding='UTF-8';if(!f.open('r'))throw Error('Cannot read '+f.fsName);var s=f.read();f.close();if(s.indexOf('lkElementsImport')<0)continue;
 if(s.indexOf('lokaya-bilingual-import-v1')<0){var marker='added = target.layers.add(source);';if(s.indexOf(marker)<0)throw Error('Unsupported importer: '+f.fsName);
 var patched=s.replace(marker,"if(kind === 'aep') lkPrepareBilingual(introduced);\n        "+marker)+'\n'+helper;
 if(!f.copy(f.fsName+'.before-bilingual.bak'))throw Error('Cannot back up '+f.fsName);
 if(!f.open('w'))throw Error('Cannot write '+f.fsName);f.write(patched);f.close();}count++;
 }catch(e){errors.push(String(e));}}
 }
 if(!count){alert('Installation failed: '+errors.join('\n'));return;}
 eval(helper);var items=[];if(app.project)for(var i=1;i<=app.project.numItems;i++)items.push(app.project.item(i));
 app.beginUndoGroup('Lokaya bilingual titles');try{var fixed=lkPrepareBilingual(items);alert('Installed. Prepared '+fixed+' text documents in the open project. Save your project, then restart After Effects. Future Elements imports are prepared automatically.');}catch(e){alert('Importer installed, but current project preparation failed: '+e);}finally{app.endUndoGroup();}
})();
