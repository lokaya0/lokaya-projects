#target aftereffects
(function(){
 var c=app.project.activeItem;if(!(c instanceof CompItem)){alert('Open the text composition, then select the text layers.');return;}
 var layers=c.selectedLayers,n=0,warnings=[];app.beginUndoGroup('Lokaya Arabic text');
 try{for(var i=0;i<layers.length;i++){var l=layers[i],p=l.property('ADBE Text Properties');if(!p)continue;p=p.property('ADBE Text Document');
 if(p.expressionEnabled){warnings.push(l.name+': Source Text expression controls this layer; edit the original text layer.');continue;}
 var count=p.numKeys||1;for(var k=1;k<=count;k++){var t=p.numKeys?p.keyValue(k):p.value;
 try{t.composerEngine=ComposerEngine.UNIVERSAL_TYPE_ENGINE;}catch(e){warnings.push(l.name+': Universal composer is unavailable in this AE version.');}
 try{t.direction=ParagraphDirection.RIGHT_TO_LEFT;}catch(e){warnings.push(l.name+': set Right-to-left manually in Paragraph.');}
 if(p.numKeys)p.setValueAtKey(k,t);else p.setValue(t);
 }n++;}
 }finally{app.endUndoGroup();}
 alert('Updated '+n+' text layers. Use an Arabic-capable font.\n'+warnings.join('\n'));
})();
